<?php
	$server = "localhost";
	$uid = "root";
	$pass = "";
	$database = "analitics";
?>